update customer set C_email = "" where C_address = "" and C_pincode = "";
update customer set C_email = "" where C_address = "" and C_pincode = "";
